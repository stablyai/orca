# PR #25654 resumed final-head remote QA — stopped safety gate

## Outcome

No Electron acceptance was run. The required immediate post-worker-start safety recheck found an unattributed real Codex configuration change while the child-worktree trust count was unchanged, so the authorization requires a stop before auditing or launching the prepared isolated harness.

## Target and environment

- Checked branch: `OrcaWin/pr-25654-remote-qa-2`
- Pinned source SHA: `ef73e249cd61eadb289b4a2590fafed294204a29`
- Agent requested/used for this dispatch: Codex `gpt-5.6-terra`, medium effort
- Platform: M4Air macOS
- Isolated `HOME`, `CODEX_HOME`, `CLAUDE_CONFIG_DIR`, and resolved Electron `userData`: not created or verified, because no driver/app launch was permitted after the safety stop.

## Required safety baseline and observed recheck

Fresh coordinator-supplied pre-start values:

- `~/.codex/hooks.json` SHA-256: `78922a784ee78e9e50587e93628cd3b9d4dfbe49087adc4514e6781cea38cbb9`
- `~/.codex/config.toml` SHA-256: `4b0e823438ad3f56d0bc3b5d31a96ba0e604e7949aa2184f6b8e8c843c3363bf`
- exact `grep -c -F '/Users/m4air/orca/workspaces/orca/pr-25654-remote-qa-2' ~/.codex/config.toml`: `1`

Immediate recheck after this worker started:

- `~/.codex/hooks.json` SHA-256: unchanged, `78922a784ee78e9e50587e93628cd3b9d4dfbe49087adc4514e6781cea38cbb9`
- `~/.codex/config.toml` SHA-256: changed to `f12888170b83c5748f2f513d00ec85972ef6880bdd2fb86ec10412162763dabf`
- exact own-child trust count: still `1`

The constant trust count means this is not attributable solely to this child worktree's trust entry. No real Codex file content was read. An escalation was sent to the coordinator before any app, test driver, fixture, or source launch action.

## Rendered and DOM evidence

None: no Electron process was launched, no CDP connection was opened, and no screenshots were captured. Therefore there is no action/DOM identity evidence for mounting settled English rows, dynamically switching the app locale to Spanish, preserving the row/header DOM identity, or showing translated run/failure/tool/Subagent/background/diff content.

## Process and evidence handling

No detached driver or Orca app process was started, so there are no owned PID/group cleanup actions. Existing prior harness, evidence, reports, and the prepared child were left untouched; this new report is the only artifact written.

## Limitations and remaining work

This is a safety-stop report, not final-head acceptance. After a coordinator-provided fresh matched baseline, the remaining work is to audit the existing isolated launcher against current source, confirm resolved userData isolation, seed the native-chat fixture without a real account/agent, perform hidden CDP dark/light acceptance including the identity-preserving locale switch, inspect uncropped screenshots, attach them, and report the macOS-only limitation (Windows/Linux/SSH/mobile runtime remains untested).
