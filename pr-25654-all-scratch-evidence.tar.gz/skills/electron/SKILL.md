---
name: electron
description: 'Launch, automate, and validate Electron desktop apps using playwright-cli via Chrome DevTools Protocol. Use this skill to validate UI changes in Orca, test features in the running Electron app, verify code fixes work end-to-end, or automate any Electron app (VS Code, Slack, Discord, etc.). Triggers include "validate in Electron", "test in the app", "verify the fix", "check the UI"'
allowed-tools: Bash(playwright-cli:*), Bash(npx playwright-cli:*), Bash(curl:*), Bash(lsof:*), Bash(open:*), Bash(ps:*), Bash(kill:*), Bash(node:*), Bash(pnpm:*), Read, Grep, Monitor
---

# Electron App Automation

Automate any Electron desktop app using playwright-cli's CDP attach mode. Electron apps are built on Chromium and expose a Chrome DevTools Protocol (CDP) port that playwright-cli can connect to, enabling the same snapshot-interact workflow used for web pages.

## Orca merge-confidence rule

If the user is asking whether an Orca branch is safe to merge, successful CDP attach plus store inspection is **not** enough evidence. For Orca validation, this skill must prove the visible app behavior as rendered on screen and call out any remaining gaps explicitly.

## Critical Safety Rule: Never Kill Processes You Didn't Start

**You may be running inside an Electron app (e.g., Orca).** Killing the wrong process will terminate your own session.

- **NEVER** run `killall Electron`, `pkill Electron`, or any broad process-killing command.
- **NEVER** kill a process unless you launched it yourself in this session and you recorded its PID.
- Before killing, **always verify** the PID belongs to the process you started — check the command line includes the workspace path or args you used to launch it.
- When quitting apps to relaunch with `--remote-debugging-port`, use `osascript -e 'quit app "AppName"'` for named apps (Slack, VS Code, etc.) — **never for Orca or the app you're running inside**.
- If unsure whether a process is safe to kill, **ask the user**.

## Core Workflow

1. **Launch** the Electron app with remote debugging enabled (or find an already-running app with CDP)
2. **Attach** playwright-cli to the CDP endpoint
3. **Snapshot** to discover interactive elements
4. **Interact** using element refs
5. **Re-snapshot** after navigation or state changes

For Orca UI work, add a final visible-proof step: inspect the rendered state directly and record what you actually saw before declaring success.

```bash
# Launch an Electron app with remote debugging
open -a "Slack" --args --remote-debugging-port=9222

# Wait for the app to initialize
sleep 3

# Attach playwright-cli to the app via CDP
command playwright-cli attach --cdp="http://localhost:9222"

# Standard workflow from here
command playwright-cli snapshot
command playwright-cli click e5
command playwright-cli screenshot
```

## Always prefix with `command`

Use `command playwright-cli …` to bypass shell aliases (e.g. `alias playwright-cli='playwright-cli --persistent'`) that leak flags into subcommands. Behaves identically when no alias is set. All examples below use this form.

## Pick a free CDP port

Port 9333 is a convention, not a guarantee — another worktree may hold it, and electron-vite will start without a debugger, letting you silently attach to the old app.

```bash
for p in 9333 9334 9335 9336 9337 9338 9339 9340; do
  if ! lsof -i :$p >/dev/null 2>&1; then PORT=$p; break; fi
done
# After attach, verify you hit the right worktree:
command playwright-cli eval "window.__store.getState().worktreesByRepo"
```

## Launching Orca Dev Build with CDP

Orca uses electron-vite for dev builds. Always launch from the target worktree root through `config/scripts/run-electron-vite-dev.mjs`; the runner seeds `ORCA_DEV_INSTANCE_LABEL` and a branch-based Dock title from that worktree/branch, then the app uses the same identity in its window title, macOS Dock hover title/badge, and automation-visible app identity.

```bash
# Launch with remote debugging (PORT picked above)
REMOTE_DEBUGGING_PORT=$PORT node config/scripts/run-electron-vite-dev.mjs 2>&1 &
ORCA_LAUNCH_PID=$!

# Poll the CDP endpoint until it returns a populated target list. `sleep 3`
# is racy — `/json` can return non-JSON or an empty array briefly during
# startup, which makes the next attach fail.
for i in $(seq 1 60); do
  curl -s "http://localhost:$PORT/json" 2>/dev/null | grep -q '"type"' && break
  sleep 1
done

command playwright-cli attach --cdp="http://localhost:$PORT"

# Confirm CDP attached to the intended worktree instance, not an older app on
# the same port from another terminal.
command playwright-cli eval "(async () => JSON.stringify(await window.api.app.getIdentity()))()"

# On macOS, verify the actual Dock tile label through Accessibility. This is
# stronger than checking Electron's internal app name, which can still be
# "Electron" while the Dock hover/title is correct.
osascript -e 'tell application "System Events" to tell process "Dock" to get name of UI elements of list 1' | grep 'Orca Dev'
```

**Key details:**
- Prefer the wrapper script with `REMOTE_DEBUGGING_PORT=$PORT` so the flag is passed through consistently. Do NOT use `pnpm run dev -- --`; the double `--` breaks Chromium flag parsing.
- The dev runner prints `[orca-dev] Instance: ... [BADGE]`; that label and badge should match the worktree/branch you intend to automate.
- On macOS, the runner names the copied `.app` bundle from the branch title because the Dock hover follows that bundle filename for direct electron-vite launches.
- The Zustand store is exposed at `window.__store` — use `window.__store.getState()` and `window.__store.getState().someAction()` to read/mutate state
- Start the CDP scan at 9333 instead of 9222 to avoid conflicts with other Electron apps.
- Record `ORCA_LAUNCH_PID`; cleanup depends on killing only the process tree you started.

### If Orca's renderer port is occupied

If startup logs show `listen EADDRINUSE` or `listen EPERM` on `5173`, check the listener. If it belongs to another worktree, do not kill it; launch this validation on an alternate renderer port instead.

```bash
lsof -nP -iTCP:5173 -sTCP:LISTEN

for p in 5174 5175 5176 5177 5178 5179 5180 5181 5182; do
  if ! lsof -nP -iTCP:$p -sTCP:LISTEN >/dev/null 2>&1; then RENDERER_PORT=$p; break; fi
done
test -n "${RENDERER_PORT:-}" || { echo "No free renderer port found" >&2; exit 1; }
TMP_CONFIG="${TMPDIR:-/tmp}/orca-electron-vite-$RENDERER_PORT.mjs"
ROOT="$(pwd)"
cat > "$TMP_CONFIG" <<EOF
import base from '$ROOT/electron.vite.config.ts';
export default { ...base, renderer: { ...base.renderer, server: { ...(base.renderer?.server ?? {}), host: '127.0.0.1', port: $RENDERER_PORT, strictPort: true } } };
EOF

REMOTE_DEBUGGING_PORT=$PORT ORCA_DEV_USER_DATA_PATH="$(mktemp -d "${TMPDIR:-/tmp}/orca-electron-profile.XXXXXX")" node config/scripts/run-electron-vite-dev.mjs -c "$TMP_CONFIG" 2>&1 &
ORCA_LAUNCH_PID=$!

for i in $(seq 1 60); do
  curl -s "http://127.0.0.1:$PORT/json" 2>/dev/null | grep -q "\"url\":\"http://127.0.0.1:$RENDERER_PORT/" && break
  sleep 1
done
command playwright-cli attach --cdp="http://127.0.0.1:$PORT"
```

Do not retry with `--host 127.0.0.1`; Orca's wrapper does not support that as an electron-vite dev flag. If the alternate renderer port also fails, report the renderer bind error and do not call it a CDP failure unless the renderer started and `/json` still failed.

### Orca-specific completion bar

For Orca branch validation, do not stop at "the command worked" or "the store updated." Before reporting merge confidence, explicitly verify:

- you attached to the intended worktree/app instance
- the user-visible UI state matches the changed behavior
- the action was exercised through the real surface when possible
- any untested state or neighboring risk is called out

When the task is primarily visual, use `orca-ui-verify` after the Electron setup. When the task is about agent-state correctness, use `test-agents` after the Electron setup.

### Accessing Orca State via eval

`playwright-cli eval` expects a single JS expression, not statements — so wrap the body in a self-invoking arrow. Use the **async** form whenever you await an `await window.api.*` IPC call or a store action that returns a Promise (`createWorktree`, `removeWorktree`, `fetchAllWorktrees`, etc.). Always JSON-stringify the return value — playwright-cli truncates / mangles raw objects.

```bash
# Sync read
command playwright-cli eval "(() => { const s = window.__store.getState(); return JSON.stringify({ activeWorktreeId: s.activeWorktreeId }); })()"

# Async — await IPC + return JSON
command playwright-cli eval "(async () => {
  const s = window.__store.getState();
  const repoId = s.repos[0].id;
  const res = await s.createWorktree(repoId, 'test-' + Date.now(), 'main', 'inherit');
  return JSON.stringify({ id: res.worktree.id, lastActivityAt: res.worktree.lastActivityAt });
})()"
```

#### Bypassing UI-only flows

A few store actions open native dialogs (folder pickers, confirms) that can't be driven via CDP. Call the underlying IPC instead, then refresh the store:

- `s.addRepo()` → `await window.api.repos.add({ path })`, then `await s.fetchRepos()`
- `s.removeWorktree(id, force)` → pass `force = true` to skip the confirm modal

Other store actions (`createWorktree`, `fetchAllWorktrees`, `bumpWorktreeActivity`, …) have no native UI and are safe to call directly.

## Launching Electron Apps with CDP

Every Electron app supports the `--remote-debugging-port` flag since it's built into Chromium.

### macOS

```bash
# Slack
open -a "Slack" --args --remote-debugging-port=9222

# VS Code
open -a "Visual Studio Code" --args --remote-debugging-port=9223

# Discord
open -a "Discord" --args --remote-debugging-port=9224

# Figma
open -a "Figma" --args --remote-debugging-port=9225

# Notion
open -a "Notion" --args --remote-debugging-port=9226

# Spotify
open -a "Spotify" --args --remote-debugging-port=9227
```

### Linux

```bash
slack --remote-debugging-port=9222
code --remote-debugging-port=9223
discord --remote-debugging-port=9224
```

### Windows

```bash
"C:\Users\%USERNAME%\AppData\Local\slack\slack.exe" --remote-debugging-port=9222
"C:\Users\%USERNAME%\AppData\Local\Programs\Microsoft VS Code\Code.exe" --remote-debugging-port=9223
```

**Important:** If the app is already running, quit it first, then relaunch with the flag. The `--remote-debugging-port` flag must be present at launch time.

## Connecting to an Already-Running App

If an Electron app was already launched with `--remote-debugging-port`, you can attach directly:

```bash
# Check what's listening on a port
lsof -i :9222

# Verify the CDP endpoint has targets
curl -s http://localhost:9222/json

# Attach playwright-cli
command playwright-cli attach --cdp="http://localhost:9222"
```

## Attaching

```bash
# Attach to a specific CDP port
command playwright-cli attach --cdp="http://localhost:9222"

# Attach with a named session (for controlling multiple apps)
command playwright-cli -s=slack attach --cdp="http://localhost:9222"
command playwright-cli -s=vscode attach --cdp="http://localhost:9223"
```

After `attach`, all subsequent commands (in that session) target the connected app.

## Tab Management

Electron apps may have multiple windows or webviews. Use tab commands to list and switch between them:

```bash
# List all available targets
command playwright-cli tab-list

# Switch to a specific tab by index
command playwright-cli tab-select 2
```

If `tab-list` doesn't show all targets, query the CDP endpoint directly to see everything:

```bash
curl -s http://localhost:9222/json | python3 -c "
import sys, json
for i, t in enumerate(json.load(sys.stdin)):
    print(f'[{i}] ({t[\"type\"]}) {t[\"title\"][:60]} - {t[\"url\"][:60]}')
"
```

## Common Patterns

### Inspect and Navigate an App

```bash
open -a "Slack" --args --remote-debugging-port=9222
sleep 3
command playwright-cli attach --cdp="http://localhost:9222"
command playwright-cli snapshot
# Read the snapshot output to identify UI elements
command playwright-cli click e10   # Navigate to a section
command playwright-cli snapshot    # Re-snapshot after navigation
```

### Take Screenshots of Desktop Apps

```bash
command playwright-cli attach --cdp="http://localhost:9222"
command playwright-cli screenshot
command playwright-cli screenshot --filename=app-state.png
```

For Orca UI validation, screenshots are evidence, not decoration. Capture the full app window or full relevant pane/surface with surrounding product context. Do not crop to a single control, component, or mock fixture unless the user explicitly asks for a cropped close-up; if you include one, it is supplemental and does not replace the uncropped screenshot. If you cannot capture the uncropped real app state, say so and stop rather than substituting a recreated crop.

### Extract Data from a Desktop App

```bash
command playwright-cli attach --cdp="http://localhost:9222"
command playwright-cli snapshot
command playwright-cli eval "document.title"
command playwright-cli eval "el => el.textContent" e5
```

### Fill Forms in Desktop Apps

```bash
command playwright-cli attach --cdp="http://localhost:9222"
command playwright-cli snapshot
command playwright-cli fill e3 "search query"
command playwright-cli press Enter
command playwright-cli snapshot
```

### Run Multiple Apps Simultaneously

Use named sessions to control multiple Electron apps at the same time:

```bash
# Attach to Slack
command playwright-cli -s=slack attach --cdp="http://localhost:9222"

# Attach to VS Code
command playwright-cli -s=vscode attach --cdp="http://localhost:9223"

# Interact with each independently
command playwright-cli -s=slack snapshot
command playwright-cli -s=vscode snapshot
```

### Run Custom Playwright Code

For advanced scenarios, use `run-code` to execute arbitrary Playwright code:

```bash
command playwright-cli run-code "async page => {
  await page.waitForSelector('.loading', { state: 'hidden' });
  const items = await page.locator('.item').allTextContents();
  return items;
}"
```

## Troubleshooting

### "Connection refused" or "Cannot connect"

- Make sure the app was launched with `--remote-debugging-port=NNNN`
- If the app was already running, quit and relaunch with the flag
- Check that the port isn't in use by another process: `lsof -i :9222`

### App launches but attach fails

- Prefer polling over `sleep N`: `for i in $(seq 1 60); do curl -s http://localhost:9222/json 2>/dev/null | grep -q '"type"' && break; sleep 1; done`
- Some apps take time to initialize their webview
- Verify the endpoint is responding: `curl -s http://localhost:9222/json`

### Elements not appearing in snapshot

- The app may use multiple webviews. Use `playwright-cli tab-list` to list targets and switch
- Use `curl -s http://localhost:<port>/json` to see all CDP targets if tab-list shows fewer
- Try `playwright-cli snapshot` without flags first

### Cannot type in input fields

- Some Electron apps use custom input components
- Try `playwright-cli press` for keyboard events
- Use `playwright-cli run-code` for complex input scenarios

### Stale element refs after interaction

- Element refs change when the page state updates
- Always re-snapshot after clicking, navigating, or filling forms
- Use the new refs from the latest snapshot

### Orca branch "looks merged-safe" but proof is weak

- For Orca, "store says it changed" is weaker evidence than "the visible screen shows the right thing"
- If the user asked for merge confidence and you did not inspect the rendered state, the validation is incomplete
- If the branch changes agent-state behavior, pair this skill with `test-agents`
- If the branch changes visible Orca UI, pair this skill with `orca-ui-verify`

## Supported Apps

Any app built on Electron works, including:

- **Communication:** Slack, Discord, Microsoft Teams, Signal, Telegram Desktop
- **Development:** VS Code, GitHub Desktop, Postman, Insomnia
- **Design:** Figma, Notion, Obsidian
- **Media:** Spotify, Tidal
- **Productivity:** Todoist, Linear, 1Password

If an app is built with Electron, it supports `--remote-debugging-port` and can be automated with playwright-cli.

## Cleaning Up

```bash
# Close the playwright-cli session (does NOT kill the Electron app)
command playwright-cli close

# Close a named session
command playwright-cli -s=slack close

# Close all playwright-cli sessions
command playwright-cli close-all
```

For Orca dev validation, also stop only the process group you recorded from this session:

```bash
test -n "${ORCA_LAUNCH_PID:-}" || { echo "ORCA_LAUNCH_PID is not set" >&2; exit 1; }
ORCA_CMD="$(ps -p "$ORCA_LAUNCH_PID" -o command=)"
case "$ORCA_CMD" in *"$(pwd)"*|*"${TMP_CONFIG:-__no_tmp_config__}"*) ;; *) echo "Refusing to kill: $ORCA_CMD" >&2; exit 1 ;; esac
ORCA_PGID="$(ps -p "$ORCA_LAUNCH_PID" -o pgid= | tr -d ' ')"
test -n "$ORCA_PGID" && kill -TERM -"$ORCA_PGID"
lsof -nP -iTCP:$PORT -sTCP:LISTEN || true
[ -z "${RENDERER_PORT:-}" ] || lsof -nP -iTCP:$RENDERER_PORT -sTCP:LISTEN || true
```

## What to report

For Orca validation, end with:

- what exact scenario was tested
- what visible evidence was observed
- what backing state/evidence was checked
- what remains unverified

Do not say "safe to merge" unless the visible behavior and the relevant backing behavior were both checked or the remaining gaps were explicitly accepted.
