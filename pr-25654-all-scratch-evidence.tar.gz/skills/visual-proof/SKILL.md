---
name: visual-proof
description: 'Use to create and attach visual proof (screenshots, videos) to a PR'
---

# visual-proof
  * Depedning on the task you may want a screenshot OR video attached.
  * Try to always add a before + after screenshot or video to show the change.

## Capture a screenshot

You can use the ../electron skill to control Orca and capture a screenshot.
Or you can write a Playwright script to capture + save a screenshot.


## Capture a video

### Build the proof into the test first

A video that merely looks correct can hide a one-frame flash. Assert the handoff frame by frame, then record the run that passes:

```ts
const firstTargetFrame = frames.findIndex((frame) => frame.targetPresented)

expect(firstTargetFrame).toBeGreaterThan(0)
expect(frames[firstTargetFrame]?.targetBufferContainsMarker).toBe(true)
expect(
  frames
    .slice(0, firstTargetFrame)
    .every((frame) => frame.previousPresented && !frame.targetPresented)
).toBe(true)
```

### Record repeated passing runs

Run this skill folder's script from the Orca repo root:

```bash
<skill-dir>/scripts/record-e2e-video.sh tests/e2e/<spec>.spec.ts '<test title substring>' 3
```

It builds the e2e-mode bundle if needed, runs with `ORCA_E2E_RECORD_VIDEO=1 --workers=1 --repeat-each=3`, refuses to hand you a video of a failing run, and prints the `.webm` paths it produced.

Why those flags: `--repeat-each=3` is stronger evidence than one lucky pass;

Recording details worth knowing:

- The fixture records a fixed **1920×1080** WebM into `testInfo.outputDir` (`tests/e2e/helpers/orca-app.ts`). A smaller app window is letterboxed inside that frame — set the viewport if that matters.
- Filenames are Playwright GUIDs (`page@<hex>.webm`), one per BrowserWindow. Glob for them; never hardcode.
- WebM keeps quality and is far smaller than a GIF of the same clip.


## Attaching
Use gh-cli and the gh-image (prefer) or gh-attach to attach the video/screenshots
Despite its name, `gh image` accepts any GitHub-supported attachment.

```bash
gh image --repo stablyai/orca "$proof"
```

Update the PR body with `gh pr edit --body-file -`, or post a comment with `gh pr comment`.

### Images
Simply attach them

### Videos

Paste the bare URL on its own line
Never wrap the URL in image Markdown. GitHub recognizes the bare video attachment URL and supplies the player.

```markdown
https://github.com/user-attachments/files/.../page@recording.webm
```
