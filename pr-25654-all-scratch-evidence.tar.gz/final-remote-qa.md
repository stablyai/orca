# PR #25654 final-head remote Electron acceptance

## Outcome

Blocked before acceptance. The requested final SHA was confirmed and the exact named child branch was checked, but the real Codex configuration hash changed without a corresponding increase in this child worktree's approved trust-entry count immediately before the CDP-ready launch. The supplied safety rule requires stopping in that circumstance, so no rendered UI result, screenshot, PR attachment, source edit, commit, or push is claimed.

## Exact target and agent

- Final SHA checked: `ef73e249cd61eadb289b4a2590fafed294204a29`
- Branch in the owned child: `OrcaWin/pr-25654-remote-qa-2` (also its configured origin feature branch)
- Agent: Codex `gpt-5.6-terra`, medium effort
- Platform: macOS on the M4Air; this was a macOS-only seeded-fixture plan, not Windows, Linux, SSH, or mobile runtime validation.

## Isolation and safety evidence

The fresh rig was `/Users/m4air/orca-qa/pr-25654/final-head`, with its own `HOME`, `user-data`, `CODEX_HOME`, `CLAUDE_CONFIG_DIR`, XDG config/cache/data, pnpm cache/store, fixture, and evidence directories. The app-launch environment was scrubbed with `ORCA_BACKGROUND_LAUNCH=1`, `ORCA_DEV_USER_DATA_PATH` and E2E user-data both inside that rig, no managed account or real agent, and Electron mock-keychain arguments were supplied through the local `ELECTRON_CLI_ARGS` boundary as `--password-store=basic` and `--use-mock-keychain`.

Current source was inspected before launch: `config/scripts/run-electron-vite-dev.mjs` returns `ORCA_DEV_USER_DATA_PATH` when set, and `src/main/startup/configure-process.ts` applies that override with `app.setPath('userData', overrideUserDataPath)`. The launch log reached the named child instance and `CDP_READY` for debug port 9616 and renderer port 5198, but no UI was inspected after the mandatory safety stop.

## Hash and trust audit

The coordinator's immediate pre-start baseline was hooks `78922a784ee78e9e50587e93628cd3b9d4dfbe49087adc4514e6781cea38cbb9`, config `5c86e7f86d0c451ba78e9d53673ea75a28bef0882d4b40084c07b679ad9cdbbe`, and trust count 0. After worker start, hooks stayed `78922a784ee78e9e50587e93628cd3b9d4dfbe49087adc4514e6781cea38cbb9`; config became `8909856d53a58cf817ceac8e2f70d7cdd38e587c898586a70a43806bc5832739` while the exact count for `/Users/m4air/orca/workspaces/orca/pr-25654-remote-qa-2` rose 0 to 1, the explicitly permitted attribution.

After isolated dependency preparation and immediately before the later CDP-ready launch, hooks was still unchanged but config became `4b0e823438ad3f56d0bc3b5d31a96ba0e604e7949aa2184f6b8e8c843c3363bf` while that exact trust count remained 1. Because that is an unattributed hash change under the supplied rule, acceptance stopped; no content of either real-home file was read or recorded.

## Setup and process accounting

The exact child initially lacked `electron-vite`; after coordinator authorization, `pnpm install --frozen-lockfile --ignore-scripts` ran with a fully isolated package-manager environment, followed by an inspected and targeted `pnpm run rebuild:electron` to obtain the Electron binary and rebuild `node-pty`. No tracked production files, lockfile, docs, commits, or pushes changed.

The final harness recorded app-launch PID 79487, debug port 9616, renderer port 5198, and the final SHA in `final-head/evidence/after/launch.json`. When the mandatory stop cleanup ran, PID 79487 was already absent and neither port was listening; no broad process action was used and only the recorded own process group was eligible for termination. The local harness/evidence has been preserved for the coordinator.

## Unverified scope

No accepted visual or DOM result exists. In particular, dark/light rendering; expanded run/disclosure; command, Read/Edit, rich argv/login-shell, padded command, diff/copy, path/accessibility, Subagent/background; retained mounted DOM identity across English-to-Spanish change; screenshots; and PR image attachment all remain unverified. This run also would not have validated actual Windows/Linux/SSH/mobile runtime behavior, only the macOS seeded transcript fixture.
