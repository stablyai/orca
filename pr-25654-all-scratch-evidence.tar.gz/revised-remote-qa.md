# PR #25654 revised final-head remote QA

## Result

Incomplete: no accepted rendered capture was obtained. The first final-head isolated attempt reached CDP but the seeded native-chat surface did not mount before the 30-second fixture timeout.

## Pin and source

- Authorized SHA: `97e156f20546a83112bef59d0f867c203458129d`.
- The owned child was fetched from `origin/brennanb2025/native-chat-tool-sentences`, verified at that SHA, detached there, and tracked clean.
- Prior evidence remains intact under `final-head`; this attempt uses `revised-head` only.

## Isolation and launch

- Launcher uses `env -i`, isolated HOME, `ORCA_DEV_USER_DATA_PATH`, CODEX_HOME, ORCA_CODEX_HOME, CLAUDE_CONFIG_DIR, Grok/XDG directories, `ORCA_BACKGROUND_LAUNCH=1`, and mock keychain/password-store flags.
- Current wrapper source resolves `ORCA_DEV_USER_DATA_PATH` first.
- The first dependency refresh was frozen and script-free; Electron was subsequently provisioned with the targeted executable check. The app launched from the isolated profile, CDP advertised the isolated renderer, and the driver recorded its own PID/group and stopped its owned processes.
- Runtime isolation evidence from this attempt is limited to the isolated launch environment and CDP listener record; the app-logged userData proof was not captured before the fixture failure.

## Observations

- Before launch hooks SHA-256: `78922a784ee78e9e50587e93628cd3b9d4dfbe49087adc4514e6781cea38cbb9` (unchanged from supplied baseline).
- Before launch config SHA-256: `9fc8f3634ceab4b032a1462b230dcb04e2cfd4d0db68809b89416381c4372485`; config and own-child trust count are observations only under the revised rule.
- The fixture error is `TimeoutError: page.waitForSelector: Timeout 30000ms exceeded` for `[data-native-chat-root="true"]` after seeding the provider session. This is the first revised-policy QA failure; no retries were run.

## Evidence

- [Launch metadata](revised-head/evidence/after/launch.json)
- [CDP listener evidence](revised-head/evidence/after/listeners.json)
- [Failure outcome](revised-head/evidence/after/outcome.json)
- [Playwright log](revised-head/evidence/after/playwright.log)
- [Electron log](revised-head/evidence/after/electron.log)

No screenshots qualify for attachment because the requested native-chat surface was not rendered. Windows, Linux, SSH, and mobile runtime validation remain untested.

## Second approved attempt

The second, separate `second-head` attempt corrected the scratch seeding to persist the exact active `chatLeafId`, set its unified tab explicitly to `chat`, and assert that state and the provider transcript before waiting. It mounted the real native-chat portal and captured the requested dark/light command, failure, read/edit, diff, path, and subagent surfaces, but failed the required English-to-Spanish same-row identity assertion: header identity stayed the same, while tool row identities changed and several expected translated labels remained English.

The app emitted its own startup diagnostic before the single-instance lock with `userData="/Users/m4air/orca-qa/pr-25654/second-head/user-data"`; this is inside the isolated root and is the required app-logged userData proof. Hooks remained at `78922a784ee78e9e50587e93628cd3b9d4dfbe49087adc4514e6781cea38cbb9`; config hash and trust count remained observations, and the owned recorded PID group was stopped.

Evidence: [second outcome](second-head/evidence/after/outcome.json), [app userData proof](second-head/evidence/after/app-user-data-proof.txt), [state notes](second-head/evidence/after/notes.json), [full failure screenshot](second-head/evidence/after/error.png), [dark collapsed](second-head/evidence/after/01-dark-collapsed.png), and [light overview](second-head/evidence/after/09-light-overview.png). This is the second M4 attempt; no third M4 attempt was run. Windows, Linux, SSH, and mobile remain unverified.
