# PR 25654 remote Electron QA — stopped before acceptance

Outcome: failed / incomplete. The coordinator stopped Grok QA before the final SHA was checked out and before acceptance screenshots. No GitHub comment, upload, PR edit, or merge was made. The git worktree was not modified.

## Checked head

- Worktree: `/Users/m4air/orca/workspaces/orca/pr-25654-remote-qa`
- Detached HEAD: `285efa5c9dc71c486642ea96fe38ba20f0db5e47` (smoke only)
- Notified final SHA, not fetched or checked out: `a2c56f22bfaae376942e07e3d85f55967ebacc15`
- Platform: macOS, arm64, Node v24.19.0
- Git status was clean. No production edits, commits, or pushes.

## What launched

The hidden isolated dev app was smoke-launched three times with `ORCA_BACKGROUND_LAUNCH=1`, a scrubbed environment, and dedicated rig homes. CDP attached to this worktree. Onboarding was closed on the third launch. The seeded transcript did not reach native-chat screenshots because the pane key was not available before the stop. No real coding agent ran. No managed account was seeded.

Stopped process IDs recorded by the driver or this worker:

- First smoke: 32855, 33219, 33471
- Second smoke main: 45310, 45320, 45694; leftover helpers later stopped: 45728 (crashpad), 45744 (daemon)
- Third smoke: 69629, 69663, 69795, 69876, 69962

A process scan after the stop found none of these still running, and none whose command contained this rig's user-data, home, harness, or this worktree's `out/electron-dev`.

## Isolation paths

- Rig: `/Users/m4air/orca-qa/pr-25654`
- HOME and agent config dirs: `/Users/m4air/orca-qa/pr-25654/home` (`.codex`, `.claude`, `.grok` under that home)
- userData: `/Users/m4air/orca-qa/pr-25654/user-data`
- Fixture and transcript: `/Users/m4air/orca-qa/pr-25654/fixture`
- Harness: `/Users/m4air/orca-qa/pr-25654/harness`
- Evidence: `/Users/m4air/orca-qa/pr-25654/evidence`
- Smoke screenshots that exist are the error frames only: `evidence/smoke/error.png`

## Real profile hashes

Only `~/.codex/hooks.json` and `~/.codex/config.toml` were hashed. Contents were not printed or copied. This worker did not read or write `~/.grok`, `~/.claude`, the keychain, or the live Orca profile. Each completed run compared the immediate pre-UI hash with the post-run hash and they matched. `config.toml` changed between runs while this app was not running.

- hooks.json, unchanged throughout: `78922a784ee78e9e50587e93628cd3b9d4dfbe49087adc4514e6781cea38cbb9` bytes=18 mtime=1790970598
- config.toml initial snapshot, before any launch: `7c85a82a644cf9caa73caecf13f30d8604619f4a09c219ffccbe5a9f61a02417` bytes=3863 mtime=1791239457
- config.toml last run, launch and after, equal: `94bb95217e86b0ed8cf4cd15da0c0c30762dcd4c0668070110bce9f6223d57da` bytes=4315 mtime=1791244855

The files were not restored.

## Rendered and unverified

Rendered in smoke: dark Orca window, isolated fixture workspace, Terminal 1 with a shell prompt, and once the onboarding agent picker. Not acceptance evidence.

Unverified: tool-run expansion, command failure output, Read/Edit/Search/Subagent rows, F1 richer input, F2 Spanish failure labels, F3 padded command, light theme, and the final SHA `a2c56f22bfaae376942e07e3d85f55967ebacc15`.

Harness and evidence are preserved for the replacement.
