# PR #25654 second-head offline diagnosis

## Scope

This report audits the preserved second M4 final-head QA artifacts for `97e156f20546a83112bef59d0f867c203458129d`. It is offline-only: no third app launch and no production source change occurred.

## Result

The saved failure is an assertion failure, not evidence of a product regression. `outcome.json` records `sameHeader: true` and `sameRows: false`; the harness sampled every `[data-native-chat-window] button` before opening the tool-run disclosure, then compared that array after opening multiple disclosures and scrolling them into view.

The comparison includes unrelated descendant controls such as Copy message, Copy diff, and Scroll-to-top. The transcript is virtualized, so scrolling may also replace mounted window rows. The stable tool-run header stayed the same DOM node; the saved artifacts do not serialize React keys or parsed tool blocks, so they cannot establish that a tool row was remounted.

## Source basis

`NativeChatToolRun.tsx` chooses `call:<callId>` for a nonblank provider call ID and otherwise uses a signature plus occurrence index; it uses that identity for both the React key and disclosure key. The seeded transcript writes unique `toolu-*` IDs, so the intended parsed identities are provider-call identities where the projection retains them.

`I18nProvider.tsx` observes `settings.uiLanguage`, resolves `es`, and calls `i18n.changeLanguage(locale)` in an effect. `NativeChatToolRun.tsx` calls `useTranslation()`, making the run header and child labels subscribers rather than a remount-only surface.

The Spanish catalog contains the PR's expected UI labels: `Ejecutó`, `Leyó`, `Editó`, `Buscó`, `Subagente`, `Intentó leer`, `Intentó editar`, and `Llamadas a herramientas fallidas`. The visible Spanish application chrome proves locale application occurred, but the saved artifacts contain no direct spy proving the effect's exact call time.

## Fixture interpretation

The English messages `command failed: false`, `read failed: fixture denial`, `edit failed: fixture denial`, `search failed: ripgrep exited`, and `Subagent finished without extra chatter` are seed transcript output. `NativeChatToolLine` renders that output as raw detail, so it is not UI copy that should localize.

The seed's `run_in_background: true` is only a Bash tool input and does not populate `backgroundTasks` for `setAgentStatus`; therefore the fixture has no native background-task row and cannot require an `En segundo plano` label. Its diff has +/- counts but no gap or truncation label, so searching for `línea` is likewise not a valid assertion of this fixture's diff behavior.

## Isolation and integrity

The app's own saved startup diagnostic reports `userData="/Users/m4air/orca-qa/pr-25654/second-head/user-data"`, within the isolated rig. The launch and after records both report hooks SHA-256 `78922a784ee78e9e50587e93628cd3b9d4dfbe49087adc4514e6781cea38cbb9` and config SHA-256 `9fc8f3634ceab4b032a1462b230dcb04e2cfd4d0db68809b89416381c4372485`; config is an observation only.

Offline comparison with origin/main `08a970a3f1176e2de1450acedb706200ef5191fb` shows this PR changes the tool line/run presentation and adds Spanish row labels, but not the transcript-window implementation. Without a same-fixture base app run, this source comparison cannot attribute a visual behavior deviation to the PR.

## Remaining coverage

The second M4 acceptance run remains incomplete because its assertion was invalid and no replacement run is authorized. Windows, Linux, SSH, and mobile remain unverified.
