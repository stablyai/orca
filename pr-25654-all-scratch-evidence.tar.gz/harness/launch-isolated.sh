#!/bin/bash
# Start the QA driver with a scrubbed environment. The driver re-checks the
# boundary and refuses to launch Electron if any path escapes the rig.
set -eu
RIG="/Users/m4air/orca-qa/pr-25654/second-head"
NODE="/opt/homebrew/opt/node@24/bin/node"
if [ ! -x "$NODE" ]; then
  echo "node 24 missing" >&2
  exit 2
fi
mkdir -p "$RIG/home/.codex" "$RIG/home/.claude" "$RIG/home/.grok" "$RIG/home/.config" "$RIG/tmp" "$RIG/evidence" "$RIG/user-data"
exec /usr/bin/env -i \
  HOME="$RIG/home" \
  USER="${USER:-m4air}" \
  LOGNAME="${LOGNAME:-m4air}" \
  SHELL="/bin/bash" \
  LANG="en_US.UTF-8" \
  LC_ALL="en_US.UTF-8" \
  TMPDIR="$RIG/tmp" \
  PATH="/opt/homebrew/opt/node@24/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin" \
  CODEX_HOME="$RIG/home/.codex" \
  ORCA_CODEX_HOME="$RIG/home/.codex" \
  CLAUDE_CONFIG_DIR="$RIG/home/.claude" \
  GROK_CONFIG_DIR="$RIG/home/.grok" \
  XDG_CONFIG_HOME="$RIG/home/.config" \
  XDG_CACHE_HOME="$RIG/home/.cache" \
  XDG_DATA_HOME="$RIG/home/.local/share" \
  ORCA_BACKGROUND_LAUNCH="1" \
  ORCA_STARTUP_DIAGNOSTICS="1" \
  ORCA_DISABLE_MACOS_LOGIN_SHELL="1" \
  ORCA_DEV_USER_DATA_PATH="$RIG/user-data" \
  ORCA_E2E_HEADLESS="1" \
  ORCA_E2E_USER_DATA_DIR="$RIG/user-data" \
  ORCA_E2E_HOME_DIR="$RIG/home" \
  QA_RIG="$RIG" \
  QA_HARNESS="/Users/m4air/orca-qa/pr-25654/harness" \
  QA_REPO="/Users/m4air/orca/workspaces/orca/pr-25654-remote-qa-2" \
  "$NODE" "/Users/m4air/orca-qa/pr-25654/harness/drive.mjs" "$@"
