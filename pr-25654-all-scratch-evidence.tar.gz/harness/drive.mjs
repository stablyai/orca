// Isolated Electron QA driver for PR 25654. Launch only through launch-isolated.sh.
import { execFileSync, spawn } from 'node:child_process'
import { createHash } from 'node:crypto'
import { createWriteStream, mkdirSync, readFileSync, writeFileSync, existsSync, statSync } from 'node:fs'
import net from 'node:net'
import path from 'node:path'
import { setTimeout as delay } from 'node:timers/promises'

const RIG = process.env.QA_RIG
const HARNESS = process.env.QA_HARNESS
const REPO = process.env.QA_REPO
const PHASE = process.argv[2]
if (!RIG || !HARNESS || !REPO || !['after', 'before', 'smoke', 'spanish'].includes(PHASE)) {
  console.error('usage: drive.mjs <after|before|smoke|spanish>')
  process.exit(2)
}

const REAL_HOME = '/Users/m4air'
const FORBIDDEN_SNIPPETS = [
  `${REAL_HOME}/.codex`,
  `${REAL_HOME}/.claude`,
  `${REAL_HOME}/.grok`,
  `${REAL_HOME}/Library/Application Support/orca`
]

function insideRig(value) {
  const resolved = path.resolve(value)
  return resolved === RIG || resolved.startsWith(`${RIG}${path.sep}`)
}

function assertIsolation() {
  const home = process.env.HOME ?? ''
  const required = {
    HOME: home,
    CODEX_HOME: process.env.CODEX_HOME,
    ORCA_CODEX_HOME: process.env.ORCA_CODEX_HOME,
    CLAUDE_CONFIG_DIR: process.env.CLAUDE_CONFIG_DIR,
    GROK_CONFIG_DIR: process.env.GROK_CONFIG_DIR,
    XDG_CONFIG_HOME: process.env.XDG_CONFIG_HOME,
    TMPDIR: process.env.TMPDIR,
    ORCA_DEV_USER_DATA_PATH: process.env.ORCA_DEV_USER_DATA_PATH,
    ORCA_E2E_USER_DATA_DIR: process.env.ORCA_E2E_USER_DATA_DIR,
    ORCA_E2E_HOME_DIR: process.env.ORCA_E2E_HOME_DIR
  }
  for (const [key, value] of Object.entries(required)) {
    if (!value || !insideRig(value)) {
      throw new Error(`isolation: ${key} is not inside the rig`)
    }
  }
  if (home === REAL_HOME) {
    throw new Error('isolation: HOME is the real user home')
  }
  if (process.env.ORCA_BACKGROUND_LAUNCH !== '1') {
    throw new Error('isolation: ORCA_BACKGROUND_LAUNCH is not 1')
  }
  const allowedOrca = new Set([
    'ORCA_BACKGROUND_LAUNCH',
    'ORCA_DISABLE_MACOS_LOGIN_SHELL',
    'ORCA_DEV_USER_DATA_PATH',
    'ORCA_CODEX_HOME',
    'ORCA_E2E_HEADLESS',
    'ORCA_E2E_USER_DATA_DIR',
    'ORCA_E2E_HOME_DIR',
    'ORCA_STARTUP_DIAGNOSTICS'
  ])
  for (const [key, value] of Object.entries(process.env)) {
    if (key.startsWith('ORCA_') && !allowedOrca.has(key)) {
      throw new Error(`isolation: unexpected ${key}`)
    }
    if (typeof value === 'string' && FORBIDDEN_SNIPPETS.some((snippet) => value.includes(snippet))) {
      throw new Error(`isolation: ${key} points at a real profile path`)
    }
  }
  const pinned = readFileSync(path.join(RIG, 'PINNED_SHA'), 'utf8').trim()
  if (!/^[0-9a-f]{40}$/.test(pinned)) {
    throw new Error('PINNED_SHA is missing or not a full sha')
  }
  return pinned
}

function listenFree(port) {
  return new Promise((resolve) => {
    const server = net.createServer()
    server.once('error', () => resolve(false))
    server.listen(port, '127.0.0.1', () => {
      server.close(() => resolve(true))
    })
  })
}

async function pickPort(candidates) {
  for (const port of candidates) {
    if (await listenFree(port)) {
      return port
    }
  }
  throw new Error(`no free port in ${candidates.join(',')}`)
}

function writeTranscript(filePath) {
  const sessionId = 'qa-pr25654-seeded-claude'
  const file = path.join(RIG, 'fixture', 'src', 'main.ts')
  let eventSecond = 10
  const longCmd = `/bin/zsh -lc "qa-padded-${'segment/'.repeat(620)}end"`
  if (longCmd.length <= 4000) {
    throw new Error('fixture long command must exceed 4000 characters')
  }
  const records = [
    {
      type: 'user',
      uuid: `${sessionId}-user`,
      sessionId,
      timestamp: '2026-10-05T16:00:00.000Z',
      message: {
        role: 'user',
        content: [{ type: 'text', text: 'Show the tool activity for this change.' }]
      }
    },
    ...tool('bash-rich', 'Bash', {
      command: 'pnpm exec vitest run src/renderer/src/components/native-chat/NativeChatToolLine.test.tsx',
      argv: [
        'pnpm',
        'exec',
        'vitest',
        'run',
        'src/renderer/src/components/native-chat/NativeChatToolLine.test.tsx'
      ],
      login_shell: '/bin/zsh',
      description: 'Run the tool line tests'
    }, 'all passed\n'),
    ...tool(
      'bash-fail',
      'Bash',
      { command: 'false', description: 'Exit with a failure' },
      'command failed: false\n',
      true
    ),
    ...tool('read', 'Read', { file_path: file, offset: 10 }, 'export const greeting = "hello"\n'),
    ...tool(
      'read-fail',
      'Read',
      { file_path: 'C:\\project\\src\\config.ts', offset: 10 },
      'read failed: fixture denial\n',
      true
    ),
    ...tool(
      'edit',
      'Edit',
      {
        file_path: file,
        old_string: 'same\nold\n',
        new_string: 'same\nnew\nextra\n'
      },
      'The file main.ts has been updated.\n'
    ),
    ...tool(
      'edit-fail',
      'Edit',
      { file_path: file, old_string: 'missing\n', new_string: 'replacement\n' },
      'edit failed: fixture denial\n',
      true
    ),
    ...tool(
      'search',
      'Grep',
      { pattern: 'TODO', path: '/Users/m4air/orca-qa/pr-25654/fixture' },
      'src/main.ts:4: TODO keep the full path\n'
    ),
    ...tool(
      'search-fail',
      'Grep',
      { pattern: 'missing-symbol', path: '/Users/m4air/orca-qa/pr-25654/fixture' },
      'search failed: ripgrep exited\n',
      true
    ),
    ...tool('agent', 'Task', {
      description: 'Inspect native chat tool rows',
      prompt: 'Private subagent instructions that must stay out of the quiet row.',
      subagent_type: 'general-purpose'
    }, 'Subagent finished without extra chatter.\n'),
    ...tool('background', 'Bash', {
      command: 'sleep 1',
      description: 'Quiet background command',
      run_in_background: true
    }, ''),
    ...tool(
      'padded',
      'Bash',
      {
        command: `  ${longCmd}  `
      },
      'padded command finished\n'
    ),
    {
      type: 'assistant',
      uuid: `${sessionId}-done`,
      sessionId,
      timestamp: '2026-10-05T16:02:00.000Z',
      message: {
        role: 'assistant',
        content: [
          {
            type: 'text',
            text: 'Tool activity is in the transcript. Nothing else is running.'
          }
        ]
      }
    }
  ]
  writeFileSync(filePath, `${records.map((record) => JSON.stringify(record)).join('\n')}\n`)

  function tool(id, name, input, output, isError = false) {
    const startedAt = `2026-10-05T16:00:${String(eventSecond).padStart(2, '0')}.000Z`
    eventSecond += 2
    const completedAt = `2026-10-05T16:00:${String(eventSecond).padStart(2, '0')}.000Z`
    eventSecond += 2
    return [
      {
        type: 'assistant',
        uuid: `${sessionId}-${id}`,
        sessionId,
        timestamp: startedAt,
        message: {
          role: 'assistant',
          content: [{ type: 'tool_use', id: `toolu-${id}`, name, input }]
        }
      },
      {
        type: 'user',
        uuid: `${sessionId}-${id}-result`,
        sessionId,
        timestamp: completedAt,
        message: {
          role: 'user',
          content: [
            {
              type: 'tool_result',
              tool_use_id: `toolu-${id}`,
              content: output,
              is_error: isError
            }
          ]
        }
      }
    ]
  }
}

function seedCompletedProfile() {
  const catalog = readFileSync(
    path.join(REPO, 'src/shared/feature-interaction-catalog.ts'),
    'utf8'
  )
  const interactionIds = [...catalog.matchAll(/\bid:\s*'([^']+)'/g)].map((match) => match[1])
  const seenAt = Date.parse('2026-01-01T00:00:00.000Z')
  const profile = {
    settings: {
      telemetry: {
        optedIn: true,
        installId: '00000000-0000-4000-8000-000000000000',
        existedBeforeTelemetryRelease: false
      },
      experimentalNativeChat: true,
      theme: 'dark',
      uiLanguage: 'en'
    },
    onboarding: {
      flowVersion: 4,
      closedAt: 1,
      outcome: 'completed',
      lastCompletedStep: 5
    },
    ui: {
      featureTipsSeenIds: ['agent-session-search', 'voice-dictation', 'orca-cli', 'cmd-j-palette'],
      featureInteractions: Object.fromEntries(
        interactionIds.map((id) => [id, { firstInteractedAt: seenAt }])
      ),
      contextualToursSeenIds: [
        'workspace-board',
        'browser',
        'tasks',
        'automations',
        'workspace-creation'
      ],
      contextualToursAutoEligible: false,
      projectOrderManualDefaultNoticeDismissed: true,
      browserImportHintHidden: true,
      usagePercentageDisplayChangeNoticeDismissed: true
    }
  }
  const userData = path.join(RIG, 'user-data')
  mkdirSync(userData, { recursive: true })
  writeFileSync(path.join(userData, 'orca-data.json'), `${JSON.stringify(profile, null, 2)}\n`)
}

function gitHead() {
  return execFileSync('git', ['-C', REPO, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim()
}

function assertPinnedCheckout(pinned) {
  const head = gitHead()
  if (head !== pinned) {
    throw new Error(`HEAD ${head} does not match PINNED_SHA ${pinned}`)
  }
  if (PHASE === 'after') {
    const finalPath = path.join(RIG, 'FINAL_SHA')
    if (!existsSync(finalPath)) {
      throw new Error('acceptance refused: FINAL_SHA is absent')
    }
    const finalSha = readFileSync(finalPath, 'utf8').trim()
    if (finalSha !== head) {
      throw new Error('acceptance refused: FINAL_SHA does not match HEAD')
    }
  }
  return head
}

function hashCodexFiles() {
  return ['hooks.json', 'config.toml'].map((name) => {
    const filePath = path.join(REAL_HOME, '.codex', name)
    const bytes = readFileSync(filePath)
    return {
      name,
      sha256: createHash('sha256').update(bytes).digest('hex'),
      bytes: bytes.length,
      mtime: Math.floor(statSync(filePath).mtimeMs / 1000)
    }
  })
}

function extractSeedResult(output) {
  const start = output.lastIndexOf('{"ok":')
  if (start < 0) {
    return null
  }
  let depth = 0
  let inString = false
  let escape = false
  for (let index = start; index < output.length; index += 1) {
    const char = output[index]
    if (inString) {
      if (escape) {
        escape = false
      } else if (char === '\\') {
        escape = true
      } else if (char === '"') {
        inString = false
      }
      continue
    }
    if (char === '"') {
      inString = true
    } else if (char === '{') {
      depth += 1
    } else if (char === '}') {
      depth -= 1
      if (depth === 0) {
        return JSON.parse(output.slice(start, index + 1))
      }
    }
  }
  return null
}

function formatHashes(rows) {
  return `${rows.map((row) => `${row.name} sha256=${row.sha256} bytes=${row.bytes} mtime=${row.mtime}`).join('\n')}\n`
}

function commandOf(pid) {
  try {
    return execFileSync('ps', ['-p', String(pid), '-o', 'command='], { encoding: 'utf8' }).trim()
  } catch {
    return ''
  }
}

function listenerPids(port) {
  let text = ''
  try {
    text = execFileSync('lsof', ['-nP', `-iTCP:${port}`, '-sTCP:LISTEN'], { encoding: 'utf8' })
  } catch {
    return []
  }
  const pids = new Set()
  for (const line of text.split('\n').slice(1)) {
    const pid = line.trim().split(/\s+/)[1]
    if (pid && /^\d+$/.test(pid)) {
      pids.add(Number(pid))
    }
  }
  return [...pids]
}

function ownedPids(cdp, overlay) {
  const portArg = `--remote-debugging-port=${cdp}`
  const text = execFileSync('ps', ['-ax', '-o', 'pid=,command='], { encoding: 'utf8' })
  const pids = []
  for (const line of text.split('\n')) {
    const match = line.match(/^\s*(\d+)\s+(.*)$/)
    if (!match) {
      continue
    }
    const cmd = match[2]
    const owned =
      cmd.includes(portArg) ||
      cmd.includes(overlay) ||
      (cmd.includes('run-electron-vite-dev.mjs') &&
        cmd.includes('pr-25654-remote-qa') &&
        cmd.includes(overlay)) ||
      (cmd.includes(path.join(RIG, 'user-data')) &&
        (cmd.includes('daemon-entry.js') || cmd.includes('chrome_crashpad_handler')))
    if (owned) {
      pids.push(Number(match[1]))
    }
  }
  return pids
}

function forbiddenOpenFiles(pid) {
  let text = ''
  try {
    text = execFileSync('lsof', ['-nP', '-p', String(pid)], {
      encoding: 'utf8',
      maxBuffer: 8 * 1024 * 1024
    })
  } catch (error) {
    text = typeof error.stdout === 'string' ? error.stdout : ''
  }
  return FORBIDDEN_SNIPPETS.filter((snippet) => text.includes(snippet))
}

function assertProcessIsolation(cdp, overlay) {
  const listeners = listenerPids(cdp)
  if (listeners.length === 0) {
    throw new Error('CDP port has no listener')
  }
  for (const pid of listeners) {
    const cmd = commandOf(pid)
    if (!cmd.includes(`--remote-debugging-port=${cdp}`)) {
      throw new Error(`CDP listener ${pid} is not this debug port`)
    }
    const worktreeOwned =
      cmd.includes('pr-25654-remote-qa') ||
      cmd.includes(path.join(RIG, 'user-data')) ||
      cmd.includes(path.join(REPO, 'out', 'electron-dev')) ||
      cmd.includes(path.join(REPO, 'node_modules', 'electron'))
    if (!worktreeOwned) {
      throw new Error(`CDP listener ${pid} is not this worktree`)
    }
  }
  const hits = []
  for (const pid of ownedPids(cdp, overlay)) {
    const found = forbiddenOpenFiles(pid)
    if (found.length > 0) {
      hits.push(`${pid}:${found.join(',')}`)
    }
  }
  if (hits.length > 0) {
    throw new Error(`isolation: real profile files are open (${hits.join(' ')})`)
  }
  return listeners
}

function stopOwned(cdp, overlay) {
  const stopped = []
  for (const pid of ownedPids(cdp, overlay)) {
    const cmd = commandOf(pid)
    const safe =
      cmd.includes(`--remote-debugging-port=${cdp}`) ||
      cmd.includes(overlay) ||
      (cmd.includes('run-electron-vite-dev.mjs') && cmd.includes('pr-25654-remote-qa')) ||
      (cmd.includes(path.join(RIG, 'user-data')) &&
        (cmd.includes('daemon-entry.js') || cmd.includes('chrome_crashpad_handler')))
    if (!safe) {
      continue
    }
    try {
      process.kill(pid, 'SIGTERM')
      stopped.push(pid)
    } catch {
      // The process already exited.
    }
  }
  return stopped
}

function runPlaywright(cdp, evidence, transcriptPath, renderer) {
  const env = {
    ...process.env,
    QA_EVIDENCE: evidence,
    QA_FIXTURE: path.join(RIG, 'fixture'),
    QA_TRANSCRIPT: transcriptPath,
    QA_RENDERER_URL: `http://127.0.0.1:${renderer}/`,
    NO_UPDATE_NOTIFIER: '1',
    PLAYWRIGHT_BROWSERS_PATH: path.join(RIG, 'home', '.cache', 'ms-playwright')
  }
  const cli = '/opt/homebrew/bin/playwright-cli'
  const session = `pr25654-${PHASE}`
  const seedSource = readFileSync(path.join(HARNESS, 'seed-page.js'), 'utf8')
  const seedRun = seedSource
    .replaceAll('__EVIDENCE__', JSON.stringify(evidence))
    .replaceAll('__FIXTURE__', JSON.stringify(path.join(RIG, 'fixture')))
    .replaceAll('__TRANSCRIPT__', JSON.stringify(transcriptPath))
    .replaceAll('__RENDERER__', JSON.stringify(`http://127.0.0.1:${renderer}/`))
    .replaceAll('__REPO__', JSON.stringify(REPO))
    .replaceAll('__SPANISH__', String(PHASE === 'spanish'))
  if (seedRun.includes('__EVIDENCE__') || seedRun.includes('process.env')) {
    throw new Error('seed script was not isolated from the driver environment')
  }
  const seedFile = path.join(RIG, 'tmp', `seed-${PHASE}.js`)
  writeFileSync(seedFile, seedRun)
  const run = (args) =>
    execFileSync(cli, args, {
      cwd: RIG,
      env,
      encoding: 'utf8',
      timeout: 240000,
      stdio: ['ignore', 'pipe', 'pipe'],
      maxBuffer: 8 * 1024 * 1024
    })
  let output = ''
  try {
    output += run([`-s=${session}`, 'attach', '--cdp', `http://127.0.0.1:${cdp}`])
    output += `\n${run([`-s=${session}`, 'run-code', '--filename', seedFile])}`
  } catch (error) {
    const stdout = typeof error.stdout === 'string' ? error.stdout : ''
    const stderr = typeof error.stderr === 'string' ? error.stderr : ''
    output += `\n${stdout}\n${stderr}\n${error.message}`
  } finally {
    try {
      output += `\n${run([`-s=${session}`, 'close'])}`
    } catch {
      // Closing a session that never attached should not hide the seed error.
    }
  }
  writeFileSync(path.join(evidence, 'playwright.log'), output)
  const result = extractSeedResult(output)
  if (!result) {
    throw new Error('playwright produced no seed result')
  }
  writeFileSync(path.join(evidence, 'outcome.json'), `${JSON.stringify({ ok: result.ok, error: result.error ?? null })}\n`)
  writeFileSync(path.join(evidence, 'notes.json'), `${JSON.stringify(result.notes ?? [], null, 2)}\n`)
  writeFileSync(path.join(evidence, 'button-names.json'), `${JSON.stringify(result.buttons ?? [], null, 2)}\n`)
  writeFileSync(path.join(evidence, 'button-names-open.json'), `${JSON.stringify(result.buttonsOpen ?? [], null, 2)}\n`)
  if (result.ok !== true) {
    throw new Error(`seed failed: ${result.error || 'unknown'}`)
  }
}

async function main() {
  const pinned = assertIsolation()
  const head = assertPinnedCheckout(pinned)
  const evidence = path.join(RIG, 'evidence', PHASE)
  mkdirSync(evidence, { recursive: true })
  const fixture = path.join(RIG, 'fixture', 'src')
  mkdirSync(fixture, { recursive: true })
  writeFileSync(
    path.join(fixture, 'main.ts'),
    'const same = true\nconst old = 1\nexport const greeting = "hello"\n// TODO keep the full path\n'
  )
  const transcriptPath = path.join(RIG, 'fixture', 'session.jsonl')
  writeTranscript(transcriptPath)
  const raw = readFileSync(transcriptPath, 'utf8')
  if (!raw.includes('tool_use') || !raw.includes('qa-padded-')) {
    throw new Error('transcript writer produced no tool calls')
  }

  const cdp = await pickPort([9616, 9617, 9618, 9619, 9620, 9621, 9622])
  const renderer = await pickPort([5198, 5199, 5200, 5201, 5202, 5203, 5204])
  const overlay = path.join(RIG, 'tmp', `electron-vite-${PHASE}-${renderer}.mjs`)
  writeFileSync(
    overlay,
    `import base from ${JSON.stringify(path.join(REPO, 'electron.vite.config.ts'))};\nexport default { ...base, renderer: { ...base.renderer, server: { ...(base.renderer?.server ?? {}), host: '127.0.0.1', port: ${renderer}, strictPort: true } } };\n`
  )
  const logPath = path.join(evidence, 'electron.log')
  const log = createWriteStream(logPath)
  seedCompletedProfile()
  const child = spawn(
    process.execPath,
    [path.join(REPO, 'config/scripts/run-electron-vite-dev.mjs'), '-c', overlay],
    {
      cwd: REPO,
      env: {
        ...process.env,
        REMOTE_DEBUGGING_PORT: String(cdp),
        ELECTRON_CLI_ARGS: JSON.stringify(['--password-store=basic', '--use-mock-keychain']),
        VITE_EXPOSE_STORE: 'true'
      },
      detached: true,
      stdio: ['ignore', 'pipe', 'pipe']
    }
  )
  child.stdout.pipe(log)
  child.stderr.pipe(log)
  writeFileSync(
    path.join(evidence, 'launch.json'),
    JSON.stringify(
      { pid: child.pid, cdp, renderer, pinned, head, phase: PHASE, overlay, acceptance: PHASE === 'after' },
      null,
      2
    )
  )
  console.log(`LAUNCH pid=${child.pid} cdp=${cdp} renderer=${renderer} head=${head}`)

  try {
    const deadline = Date.now() + 300000
    let ready = false
    while (Date.now() < deadline) {
      try {
        const response = await fetch(`http://127.0.0.1:${cdp}/json`)
        const text = await response.text()
        if (text.includes(`http://127.0.0.1:${renderer}/`)) {
          ready = true
          break
        }
      } catch {
        // CDP is not up yet.
      }
      await delay(1000)
    }
    if (!ready) {
      throw new Error('CDP did not advertise the renderer')
    }
    const startupLog = readFileSync(logPath, 'utf8')
    const isolatedUserData = path.join(RIG, 'user-data')
    if (!startupLog.includes(isolatedUserData)) {
      throw new Error('startup diagnostics did not log isolated app userData')
    }
    writeFileSync(path.join(evidence, 'app-user-data-proof.txt'), startupLog.split('\n').filter((line) => line.includes(isolatedUserData)).join('\n') + '\n')
    console.log('CDP_READY')
    const listeners = assertProcessIsolation(cdp, overlay)
    writeFileSync(path.join(evidence, 'listeners.json'), `${JSON.stringify(listeners)}\n`)
    const before = hashCodexFiles()
    writeFileSync(path.join(evidence, 'codex-hashes-launch.txt'), formatHashes(before))
    let seedError = null
    try {
      runPlaywright(cdp, evidence, transcriptPath, renderer)
      assertProcessIsolation(cdp, overlay)
    } catch (error) {
      seedError = error
    }
    const after = hashCodexFiles()
    writeFileSync(path.join(evidence, 'codex-hashes-after.txt'), formatHashes(after))
    const hooksUnchanged = before[0]?.sha256 === after[0]?.sha256 && before[0]?.bytes === after[0]?.bytes
    if (!hooksUnchanged) {
      throw new Error('HOOKS_HASH_CHANGED during this run')
    }
    if (seedError) {
      throw seedError
    }
    const outcomePath = path.join(evidence, 'outcome.json')
    if (!existsSync(outcomePath)) {
      throw new Error('seed outcome missing')
    }
    const outcome = JSON.parse(readFileSync(outcomePath, 'utf8'))
    if (outcome.ok !== true) {
      throw new Error(`seed failed: ${outcome.error || 'unknown'}`)
    }
    console.log(PHASE === 'after' ? 'ACCEPT_DONE' : 'SMOKE_DONE')
    console.log(`HEAD ${head}`)
  } finally {
    log.end()
    const stopped = stopOwned(cdp, overlay)
    console.log(`STOPPED ${stopped.join(',') || 'none'}`)
  }
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error))
  process.exit(1)
})
