async (page) => {
  const evidence = "/Users/m4air/orca-qa/pr-25654/final-head/evidence/after"
  const fixture = "/Users/m4air/orca-qa/pr-25654/final-head/fixture"
  const transcriptPath = "/Users/m4air/orca-qa/pr-25654/final-head/fixture/session.jsonl"
  const rendererUrl = "http://127.0.0.1:5198/"
  const repo = "/Users/m4air/orca/workspaces/orca/pr-25654-remote-qa-2"
  const spanish = false
  const notes = []
  const pages = page.context().pages()
  const surface =
    pages.find((candidate) => candidate.url().startsWith(rendererUrl)) ?? page
  const shot = async (name) => {
    await surface.screenshot({ path: `${evidence}/${name}`, animations: 'disabled', caret: 'hide' })
    notes.push(name)
  }
  let buttons = []
  let buttonsOpen = []

  try {
    notes.push(`page=${surface.url()}`)
    if (rendererUrl && !surface.url().startsWith(rendererUrl)) {
      throw new Error(`renderer page missing: ${pages.map((item) => item.url()).join(' | ')}`)
    }
    const client = await surface.context().newCDPSession(surface)
    await client.send('Emulation.setDeviceMetricsOverride', {
      width: 1440,
      height: 1100,
      deviceScaleFactor: 1,
      mobile: false
    })
    await surface.waitForFunction(() => window.__store?.getState, null, { timeout: 120000 })
    const identity = await surface.evaluate(async () => {
      const id = await window.api.app.getIdentity()
      return {
        isDev: id.isDev,
        devRepoRoot: id.devRepoRoot,
        devWorktreeName: id.devWorktreeName,
        devBranch: id.devBranch
      }
    })
    notes.push(`identity ${JSON.stringify(identity)}`)
    if (identity.devRepoRoot !== repo) {
      throw new Error(`identity repo ${identity.devRepoRoot} is not ${repo}`)
    }

    const seeded = await surface.evaluate(
      async ({ fixturePath, transcript, spanish }) => {
        const store = window.__store
        if (!store) {
          throw new Error('store missing')
        }
        const settings = await window.api.settings.set({
          experimentalNativeChat: true,
          theme: 'dark',
          uiLanguage: spanish ? 'es' : 'en'
        })
        store.setState({ settings })
        store.getState().setRightSidebarOpen(false)
        const added = await store.getState().addNonGitFolder(fixturePath)
        const deadline = Date.now() + 120000
        let worktreeId = null
        let tabId = null
        let paneKey = null
        let managerCount = 0
        while (Date.now() < deadline && !paneKey) {
          const state = store.getState()
          worktreeId =
            state.activeWorktreeId ??
            Object.values(state.worktreesByRepo ?? {}).flat()[0]?.id ??
            null
          if (worktreeId && state.activeWorktreeId !== worktreeId) {
            state.setActiveWorktree(worktreeId)
          }
          const tabs = worktreeId ? (state.tabsByWorktree[worktreeId] ?? []) : []
          if (worktreeId && tabs.length === 0 && state.createTab) {
            state.createTab(worktreeId)
          }
          const next = store.getState()
          const nextTabs = worktreeId ? (next.tabsByWorktree[worktreeId] ?? []) : []
          const tab = nextTabs[0]
          if (tab) {
            tabId = tab.id
            next.setActiveTab(tab.id)
            next.setActiveTabType('terminal', worktreeId)
          }
          const managers = [...(window.__paneManagers?.entries?.() ?? [])]
          managerCount = managers.length
          for (const [managerTabId, manager] of managers) {
            const pane = manager?.getActivePane?.() ?? manager?.getPanes?.()?.[0]
            if (pane?.leafId) {
              paneKey = `${managerTabId}:${pane.leafId}`
              tabId = managerTabId
              break
            }
          }
          if (!paneKey && tabId) {
            const leafId = firstLeaf(next.terminalLayoutsByTabId?.[tabId]?.root)
            if (leafId) {
              paneKey = `${tabId}:${leafId}`
            }
          }
          if (!paneKey) {
            await new Promise((resolve) => setTimeout(resolve, 500))
          }
        }
        function firstLeaf(node) {
          if (!node || typeof node !== 'object') {
            return null
          }
          if (node.type === 'leaf' && typeof node.leafId === 'string') {
            return node.leafId
          }
          return firstLeaf(node.first) || firstLeaf(node.second)
        }
        if (!paneKey || !worktreeId || !tabId) {
          const onboarding = (document.body.innerText || '').includes('Pick your default agent')
          throw new Error(
            `pane not ready worktree=${worktreeId} tab=${tabId} managers=${managerCount} onboarding=${onboarding}`
          )
        }
        store.getState().setAgentStatus(
          paneKey,
          { state: 'done', prompt: 'seeded tool sentences', agentType: 'claude' },
          'Claude',
          undefined,
          { worktreeId },
          {
            providerSession: {
              key: 'session_id',
              id: 'qa-pr25654-seeded-claude',
              transcriptPath: transcript
            }
          }
        )
        const unified = (store.getState().unifiedTabsByWorktree[worktreeId] ?? []).find(
          (tab) => tab.contentType === 'terminal' && tab.entityId === tabId
        )
        if (!unified) {
          throw new Error('unified terminal tab missing')
        }
        store.getState().toggleTabViewMode(unified.id)
        store.getState().setRightSidebarOpen(false)
        return { added: Boolean(added), worktreeId, tabId, paneKey }
      },
      { fixturePath: fixture, transcript: transcriptPath, spanish }
    )
    notes.push(`seeded ${JSON.stringify(seeded)}`)
    await surface.waitForSelector('[data-native-chat-root="true"]', { timeout: 30000 })
    await surface.waitForSelector('[data-native-chat-window]', { timeout: 30000 })
    await surface.waitForSelector('[data-native-chat-tool-run-state]', { timeout: 30000 })

    const closers = surface.locator('[data-close-button]')
    const closerCount = await closers.count()
    for (let index = 0; index < closerCount; index += 1) {
      const box = await closers.nth(index).boundingBox()
      if (!box) {
        continue
      }
      const point = { x: box.x + box.width / 2, y: box.y + box.height / 2 }
      const label = await surface.evaluate(({ x, y }) => {
        const el = document.elementFromPoint(x, y)
        return (el?.closest?.('[data-close-button]')?.getAttribute('aria-label') || el?.textContent || '')
          .replace(/\s+/g, ' ')
          .trim()
      }, point)
      if (label.includes('System Settings')) {
        continue
      }
      await surface.mouse.click(point.x, point.y)
    }

    const themeDark = await surface.evaluate(() => document.documentElement.classList.contains('dark'))
    notes.push(`darkClass=${themeDark}`)
    await shot('01-dark-collapsed.png')

    const dumpButtons = async () =>
      surface.evaluate(() =>
        [...document.querySelectorAll('[data-native-chat-window] button')].map((button) => ({
          text: (button.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 240),
          title: button.querySelector('[title]')?.getAttribute('title') ?? button.getAttribute('title'),
          sr: [...button.querySelectorAll('.sr-only')].map((node) => node.textContent || '').join(' | '),
          expanded: button.getAttribute('aria-expanded'),
          run: button.hasAttribute('data-native-chat-tool-run-state')
        }))
      )
    buttons = await dumpButtons()

    const clickBox = async (handle, needle) => {
      await handle.scrollIntoViewIfNeeded()
      const box = await handle.boundingBox()
      if (!box) {
        throw new Error(`no box for ${needle}`)
      }
      const point = { x: box.x + Math.min(24, box.width / 2), y: box.y + box.height / 2 }
      const hit = await surface.evaluate(({ x, y }) => {
        const el = document.elementFromPoint(x, y)
        const button = el?.closest?.('button')
        return {
          text: (button?.innerText || el?.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 180)
        }
      }, point)
      if (!hit.text.includes(needle)) {
        throw new Error(`hit ${JSON.stringify(hit)} missed ${needle}`)
      }
      await surface.mouse.click(point.x, point.y)
      await surface.waitForTimeout(250)
    }

    const run = surface.locator('[data-native-chat-tool-run-state]').first()
    const runText = await run.innerText()
    notes.push(`run=${runText}`)
    const mountedIdentity = await surface.evaluate(() => {
      const rows = [...document.querySelectorAll('[data-native-chat-window] button')]
      const header = document.querySelector('[data-native-chat-tool-run-state]')
      window.__pr25654MountedToolRows = { header, rows }
      return { headerPresent: Boolean(header), rowCount: rows.length }
    })
    notes.push(`mountedIdentity=${JSON.stringify(mountedIdentity)}`)
    await clickBox(run, spanish ? runText.slice(0, 3) : 'Ran')
    await surface.waitForFunction(() => {
      const header = document.querySelector('[data-native-chat-tool-run-state]')
      if (header?.getAttribute('aria-expanded') !== 'true') {
        return false
      }
      return [...document.querySelectorAll('[data-native-chat-window] button')].some(
        (button) => !button.hasAttribute('data-native-chat-tool-run-state') && (button.innerText || '').includes('false')
      )
    }, null, { timeout: 15000 })
    notes.push('opened run')

    const clickNeedle = async (needle, file) => {
      const handle = surface
        .locator('[data-native-chat-window] button:not([data-native-chat-tool-run-state])', { hasText: needle })
        .first()
      await handle.scrollIntoViewIfNeeded()
      const expanded = await handle.getAttribute('aria-expanded')
      notes.push(`${needle} aria-expanded=${expanded}`)
      if (expanded === 'false') {
        await clickBox(handle, needle)
        notes.push(`clicked ${needle}`)
      }
      await shot(file)
    }

    await clickNeedle('false', spanish ? '20-es-command-failure.png' : '02-dark-command-failure.png')
    if (spanish) {
      const toolRows = await surface.evaluate(() =>
        [...document.querySelectorAll('[data-native-chat-window] button')]
          .map((button) => ({
            text: (button.innerText || '').replace(/\s+/g, ' ').trim(),
            title: button.getAttribute('title') || button.querySelector('[title]')?.getAttribute('title') || ''
          }))
          .filter((row) => /agent|subagent|read|edit|failed|intent|leer|editar/i.test(row.text))
      )
      notes.push(`spanishRows=${JSON.stringify(toolRows)}`)
      await shot('21-es-pre-mount-labels.png')
    } else {
      await clickNeedle('vitest', '03-dark-rich-command.png')
      await clickNeedle('qa-padded-', '04-dark-padded-command.png')
      await clickNeedle('Read', '05-dark-read.png')
      await clickNeedle('Edited', '06-dark-edit.png')
      await clickNeedle('TODO', '07-dark-search.png')
      await clickNeedle('Subagent', '08-dark-subagent.png')
      await clickNeedle('Tried to read', '11-dark-failed-read-windows-path.png')
      await clickNeedle('Tried to edit', '12-dark-failed-edit.png')
      const windowsPath = await surface.evaluate(() => {
        const buttons = [...document.querySelectorAll('[data-native-chat-window] button')]
        const row = buttons.find((button) => (button.innerText || '').includes('config.ts'))
        return {
          text: (row?.innerText || '').replace(/\s+/g, ' ').trim(),
          title: row?.getAttribute('title') || row?.querySelector('[title]')?.getAttribute('title') || '',
          allText: document.body.innerText.includes('C:\\project\\src\\config.ts')
        }
      })
      notes.push(`windowsPath=${JSON.stringify(windowsPath)}`)
    }
    buttonsOpen = await dumpButtons()

    if (!spanish) await surface.evaluate(async () => {
      const settings = await window.api.settings.set({ theme: 'light', uiLanguage: 'en' })
      window.__store.setState({ settings })
    })
    if (!spanish) await surface.waitForFunction(() => document.documentElement.classList.contains('light'), null, {
      timeout: 10000
    })
    if (!spanish) await shot('09-light-overview.png')

    if (!spanish) await surface.evaluate(async () => {
      const settings = await window.api.settings.set({ theme: 'dark', uiLanguage: 'es' })
      window.__store.setState({ settings })
    })
    if (!spanish) await surface.waitForFunction(() => (document.body.innerText || '').includes('Buscar'), null, {
      timeout: 30000
    })
    if (!spanish) {
      const postMountLanguageProof = await surface.evaluate(() => {
        const prior = window.__pr25654MountedToolRows
        const currentHeader = document.querySelector('[data-native-chat-tool-run-state]')
        const currentRows = [...document.querySelectorAll('[data-native-chat-window] button')]
        const text = document.body.innerText || ''
        const padded = currentRows.find((row) => (row.innerText || '').includes('qa-padded-'))
        return {
          sameHeader: prior?.header === currentHeader,
          sameRows: prior?.rows?.length === currentRows.length && prior.rows.every((row, index) => row === currentRows[index]),
          spanish: {
            run: text.includes('Se ejecut'),
            failureAccessibility: (currentHeader?.getAttribute('aria-label') || '').includes('Llamadas a herramientas fallidas'),
            read: text.includes('Intentó leer config.ts'),
            edit: text.includes('Intentó editar main.ts'),
            subagent: text.includes('Subagente'),
            background: text.includes('En segundo plano') || text.includes('segundo plano'),
            diff: text.includes('línea') || text.includes('Línea')
          },
          paddedCommand: {
            textLength: padded?.innerText.length || 0,
            exactPrefix: (padded?.innerText || '').includes('qa-padded-segment/'),
            titleLength: padded?.getAttribute('title')?.length || 0
          }
        }
      })
      notes.push(`postMountLanguageProof=${JSON.stringify(postMountLanguageProof)}`)
      if (!postMountLanguageProof.sameHeader || !postMountLanguageProof.sameRows) {
        throw new Error(`mounted tool DOM identity changed: ${JSON.stringify(postMountLanguageProof)}`)
      }
      if (!Object.values(postMountLanguageProof.spanish).every(Boolean)) {
        throw new Error(`post-mount Spanish labels incomplete: ${JSON.stringify(postMountLanguageProof)}`)
      }
      if (!postMountLanguageProof.paddedCommand.exactPrefix || postMountLanguageProof.paddedCommand.textLength <= 4000) {
        throw new Error(`padded command is not fully rendered: ${JSON.stringify(postMountLanguageProof)}`)
      }
      await shot('10-dark-es-post-mount-identity.png')
    }
    return { ok: true, notes, buttons, buttonsOpen }
  } catch (error) {
    const message = error instanceof Error ? error.stack || error.message : String(error)
    notes.push(message.split('\n')[0])
    await shot('error.png').catch(() => {})
    return { ok: false, error: message.slice(0, 1500), notes, buttons, buttonsOpen }
  }
}
