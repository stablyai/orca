import base from "/Users/m4air/orca/workspaces/orca/pr-25654-remote-qa/electron.vite.config.ts";
export default { ...base, renderer: { ...base.renderer, server: { ...(base.renderer?.server ?? {}), host: '127.0.0.1', port: 5198, strictPort: true } } };
