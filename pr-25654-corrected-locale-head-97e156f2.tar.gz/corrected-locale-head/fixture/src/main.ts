const same = true
const old = 1
export const greeting = "hello"
// TODO keep the full path
