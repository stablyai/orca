async (page) => {
  const evidence = "/Users/m4air/orca-qa/pr-25654/corrected-locale-head/evidence/after"
  const fixture = "/Users/m4air/orca-qa/pr-25654/corrected-locale-head/fixture"
  const transcriptPath = "/Users/m4air/orca-qa/pr-25654/corrected-locale-head/fixture/session.jsonl"
  const rendererUrl = "http://127.0.0.1:5198/"
  const repo = "/Users/m4air/orca/workspaces/orca/pr-25654-remote-qa-2"
  const notes = []
  const pages = page.context().pages()
  const surface = pages.find((candidate) => candidate.url().startsWith(rendererUrl)) ?? page
  const shot = async (name) => {
    await surface.screenshot({ path: `${evidence}/${name}`, animations: 'disabled', caret: 'hide' })
    notes.push(name)
  }
  const norm = (value) => String(value || '').replace(/\s+/g, ' ').trim()
  let buttons = []
  let buttonsOpen = []

  try {
    notes.push(`page=${surface.url()}`)
    if (!surface.url().startsWith(rendererUrl)) throw new Error('renderer page missing')
    const client = await surface.context().newCDPSession(surface)
    await client.send('Emulation.setDeviceMetricsOverride', {
      width: 1440,
      height: 1100,
      deviceScaleFactor: 1,
      mobile: false
    })
    await surface.waitForFunction(() => window.__store?.getState, null, { timeout: 120000 })
    const identity = await surface.evaluate(async () => {
      const id = await window.api.app.getIdentity()
      return { isDev: id.isDev, devRepoRoot: id.devRepoRoot, devWorktreeName: id.devWorktreeName, devBranch: id.devBranch }
    })
    if (identity.devRepoRoot !== repo) throw new Error(`identity repo mismatch: ${identity.devRepoRoot}`)
    notes.push(`identity=${JSON.stringify(identity)}`)

    const seeded = await surface.evaluate(async ({ fixturePath, transcript }) => {
      const store = window.__store
      const settings = await window.api.settings.set({ experimentalNativeChat: true, theme: 'dark', uiLanguage: 'en' })
      store.setState({ settings })
      store.getState().setRightSidebarOpen(false)
      await store.getState().addNonGitFolder(fixturePath)
      const firstLeaf = (node) => {
        if (!node || typeof node !== 'object') return null
        if (node.type === 'leaf' && typeof node.leafId === 'string') return node.leafId
        return firstLeaf(node.first) || firstLeaf(node.second)
      }
      const deadline = Date.now() + 120000
      let worktreeId = null
      let tabId = null
      let paneKey = null
      let managerCount = 0
      while (Date.now() < deadline && !paneKey) {
        const state = store.getState()
        worktreeId = state.activeWorktreeId ?? Object.values(state.worktreesByRepo ?? {}).flat()[0]?.id ?? null
        if (worktreeId && state.activeWorktreeId !== worktreeId) state.setActiveWorktree(worktreeId)
        const tabs = worktreeId ? (state.tabsByWorktree[worktreeId] ?? []) : []
        if (worktreeId && tabs.length === 0) state.createTab(worktreeId)
        const next = store.getState()
        const tab = worktreeId ? (next.tabsByWorktree[worktreeId] ?? [])[0] : null
        if (tab) {
          tabId = tab.id
          next.setActiveTab(tab.id)
          next.setActiveTabType('terminal', worktreeId)
        }
        const managers = [...(window.__paneManagers?.entries?.() ?? [])]
        managerCount = managers.length
        for (const [managerTabId, manager] of managers) {
          const pane = manager?.getActivePane?.() ?? manager?.getPanes?.()?.[0]
          if (pane?.leafId) {
            paneKey = `${managerTabId}:${pane.leafId}`
            tabId = managerTabId
            break
          }
        }
        if (!paneKey && tabId) {
          const leafId = firstLeaf(next.terminalLayoutsByTabId?.[tabId]?.root)
          if (leafId) paneKey = `${tabId}:${leafId}`
        }
        if (!paneKey) await new Promise((resolve) => setTimeout(resolve, 400))
      }
      if (!paneKey || !worktreeId || !tabId) throw new Error(`pane not ready: ${worktreeId}/${tabId}/${managerCount}`)
      store.getState().setAgentStatus(
        paneKey,
        { state: 'done', prompt: 'seeded corrected locale proof', agentType: 'claude' },
        'Claude',
        undefined,
        { worktreeId },
        { providerSession: { key: 'session_id', id: 'qa-pr25654-seeded-claude', transcriptPath: transcript } }
      )
      const unified = (store.getState().unifiedTabsByWorktree[worktreeId] ?? []).find((tab) => tab.contentType === 'terminal' && tab.entityId === tabId)
      const layout = store.getState().terminalLayoutsByTabId[tabId]
      if (!unified || !layout) throw new Error('unified tab or layout missing')
      const owner = paneKey.split(':').slice(1).join(':')
      store.getState().setTabLayout(tabId, { ...layout, chatLeafId: owner })
      store.getState().setTabViewMode(unified.id, 'chat')
      const stable = store.getState()
      const mode = (stable.unifiedTabsByWorktree[worktreeId] ?? []).find((tab) => tab.id === unified.id)?.viewMode
      const status = stable.agentStatusByPaneKey[paneKey]
      if (stable.terminalLayoutsByTabId[tabId]?.chatLeafId !== owner || mode !== 'chat' || status?.state !== 'done' || status?.providerSession?.transcriptPath !== transcript || stable.settings?.experimentalNativeChat !== true) {
        throw new Error(`unstable seed owner=${stable.terminalLayoutsByTabId[tabId]?.chatLeafId} mode=${mode} status=${status?.state}`)
      }
      return { worktreeId, tabId, paneKey, owner, mode, provider: status.providerSession, experimentalNativeChat: stable.settings.experimentalNativeChat }
    }, { fixturePath: fixture, transcript: transcriptPath })
    notes.push(`seeded=${JSON.stringify(seeded)}`)
    await surface.waitForSelector('[data-native-chat-root="true"]', { timeout: 30000 })
    await surface.waitForSelector('[data-native-chat-window]', { timeout: 30000 })
    const run = surface.locator('[data-native-chat-tool-run-state]').first()
    await run.scrollIntoViewIfNeeded()
    const initialRun = norm(await run.innerText())
    if (!initialRun.startsWith('Ran ') || !initialRun.includes('failed')) throw new Error(`unexpected English run: ${initialRun}`)
    await shot('01-dark-english-collapsed.png')
    await run.click()
    await surface.waitForFunction(() => document.querySelector('[data-native-chat-tool-run-state]')?.getAttribute('aria-expanded') === 'true')

    const row = (needle) => surface.locator('[data-native-chat-window] button:not([data-native-chat-tool-run-state])').filter({ hasText: needle }).first()
    const collapse = async (needle) => {
      const target = row(needle)
      await target.scrollIntoViewIfNeeded()
      if ((await target.getAttribute('aria-expanded')) === 'true') await target.click()
    }
    await collapse('vitest')
    await collapse('qa-padded-')
    await surface.waitForTimeout(300)
    const anchor = row('Tried to edit')
    await anchor.scrollIntoViewIfNeeded()
    await surface.waitForTimeout(300)

    const beforeProof = await surface.evaluate(() => {
      const normalize = (value) => String(value || '').replace(/\s+/g, ' ').trim()
      const buttons = [...document.querySelectorAll('[data-native-chat-window] button')]
      const run = document.querySelector('[data-native-chat-tool-run-state]')
      const find = (needle) => buttons.find((button) => normalize(button.innerText).includes(needle)) ?? null
      const failedRead = find('Tried to read config.ts')
      const failedEdit = find('Tried to edit main.ts')
      const subagent = find('Subagent Inspect native chat tool rows')
      const successEdit = find('Edited main.ts')
      const copyDiff = buttons.find((button) => normalize(button.getAttribute('title')) === 'Copy diff') ?? null
      const failureLabel = run?.querySelector('[aria-label]') ?? null
      const describe = (node) => node ? {
        connected: node.isConnected,
        text: normalize(node.textContent),
        innerText: normalize(node.innerText),
        title: node.getAttribute('title'),
        aria: node.getAttribute('aria-label'),
        tag: node.tagName,
        className: node.className
      } : null
      const expected = {
        run: normalize(run?.innerText).startsWith('Ran '),
        failedRead: normalize(failedRead?.innerText).includes('Tried to read config.ts'),
        failedEdit: normalize(failedEdit?.innerText).includes('Tried to edit main.ts'),
        subagent: normalize(subagent?.innerText).includes('Subagent'),
        successEdit: normalize(successEdit?.innerText).includes('Edited main.ts'),
        copyDiff: normalize(copyDiff?.getAttribute('title')) === 'Copy diff',
        failureLabel: normalize(failureLabel?.getAttribute('aria-label')).startsWith('Failed tool calls:')
      }
      if (!Object.values(expected).every(Boolean)) throw new Error(`English semantic nodes unavailable: ${JSON.stringify({ expected, run: describe(run), failedRead: describe(failedRead), failedEdit: describe(failedEdit), subagent: describe(subagent), successEdit: describe(successEdit), copyDiff: describe(copyDiff), failureLabel: describe(failureLabel) })}`)
      window.__correctedLocaleNodes = { run, failedRead, failedEdit, subagent, successEdit, copyDiff, failureLabel }
      return { expected, mapping: Object.fromEntries(Object.entries(window.__correctedLocaleNodes).map(([key, node]) => [key, describe(node)])), buttonCount: buttons.length }
    })
    notes.push(`beforeNodeProof=${JSON.stringify(beforeProof)}`)
    await shot('02-dark-english-stable-nodes.png')

    await surface.evaluate(async () => {
      const settings = await window.api.settings.set({ theme: 'dark', uiLanguage: 'es' })
      window.__store.setState({ settings })
    })
    await surface.waitForFunction(() => {
      const nodes = window.__correctedLocaleNodes
      const normalize = (value) => String(value || '').replace(/\s+/g, ' ').trim()
      return Boolean(nodes?.run?.isConnected && nodes?.failedRead?.isConnected && nodes?.failedEdit?.isConnected && nodes?.subagent?.isConnected && nodes?.successEdit?.isConnected && nodes?.copyDiff?.isConnected &&
        normalize(nodes.run.innerText).startsWith('Se ejecut') &&
        normalize(nodes.failedRead.innerText).includes('Intentó leer config.ts') &&
        normalize(nodes.failedEdit.innerText).includes('Intentó editar main.ts') &&
        normalize(nodes.subagent.innerText).includes('Subagente') &&
        normalize(nodes.successEdit.innerText).includes('Editó main.ts') &&
        normalize(nodes.copyDiff.getAttribute('title')) === 'Copiar diff' &&
        normalize(nodes.failureLabel.getAttribute('aria-label')).startsWith('Llamadas a herramientas fallidas:'))
    }, null, { timeout: 30000 })
    const afterProof = await surface.evaluate(() => {
      const normalize = (value) => String(value || '').replace(/\s+/g, ' ').trim()
      const prior = window.__correctedLocaleNodes
      const buttons = [...document.querySelectorAll('[data-native-chat-window] button')]
      const currentRun = document.querySelector('[data-native-chat-tool-run-state]')
      const find = (needle) => buttons.find((button) => normalize(button.innerText).includes(needle)) ?? null
      const current = {
        run: currentRun,
        failedRead: find('Intentó leer config.ts'),
        failedEdit: find('Intentó editar main.ts'),
        subagent: find('Subagente Inspect native chat tool rows'),
        successEdit: find('Editó main.ts'),
        copyDiff: buttons.find((button) => normalize(button.getAttribute('title')) === 'Copiar diff') ?? null,
        failureLabel: currentRun?.querySelector('[aria-label]') ?? null
      }
      const same = Object.fromEntries(Object.keys(current).map((key) => [key, prior[key] === current[key] && prior[key]?.isConnected === true]))
      const describe = (node) => node ? { text: normalize(node.textContent), innerText: normalize(node.innerText), title: node.getAttribute('title'), aria: node.getAttribute('aria-label'), connected: node.isConnected } : null
      const labels = {
        run: normalize(prior.run.innerText),
        failedRead: normalize(prior.failedRead.innerText),
        failedEdit: normalize(prior.failedEdit.innerText),
        subagent: normalize(prior.subagent.innerText),
        successEdit: normalize(prior.successEdit.innerText),
        copyDiff: normalize(prior.copyDiff.getAttribute('title')),
        failureLabel: normalize(prior.failureLabel.getAttribute('aria-label'))
      }
      const expected = labels.run.startsWith('Se ejecut') && labels.failedRead.includes('Intentó leer config.ts') && labels.failedEdit.includes('Intentó editar main.ts') && labels.subagent.includes('Subagente') && labels.successEdit.includes('Editó main.ts') && labels.copyDiff === 'Copiar diff' && labels.failureLabel.startsWith('Llamadas a herramientas fallidas:')
      if (!expected || !Object.values(same).every(Boolean)) throw new Error(`same-node locale proof failed: ${JSON.stringify({ same, labels, prior: Object.fromEntries(Object.entries(prior).map(([key, node]) => [key, describe(node)])), current: Object.fromEntries(Object.entries(current).map(([key, node]) => [key, describe(node)])) })}`)
      return { same, labels, mapping: Object.fromEntries(Object.entries(current).map(([key, node]) => [key, describe(node)])), buttonCount: buttons.length, uiLanguage: window.__store.getState().settings?.uiLanguage }
    })
    notes.push(`afterNodeProof=${JSON.stringify(afterProof)}`)
    await shot('03-dark-spanish-same-nodes.png')

    const padded = row('qa-padded-')
    await padded.scrollIntoViewIfNeeded()
    if ((await padded.getAttribute('aria-expanded')) === 'false') await padded.click()
    await surface.waitForTimeout(200)
    const paddedProof = await surface.evaluate(() => {
      const expected = `  /bin/zsh -lc "qa-padded-${'segment/'.repeat(620)}end"  `
      const detail = [...document.querySelectorAll('[data-native-chat-window] pre')].map((node) => node.textContent || '').find((text) => text.includes('qa-padded-')) ?? ''
      return { exact: detail === expected, length: detail.length, expectedLength: expected.length, prefix: detail.slice(0, 48), suffix: detail.slice(-16) }
    })
    if (!paddedProof.exact || paddedProof.length <= 4000) throw new Error(`padded detail mismatch: ${JSON.stringify(paddedProof)}`)
    notes.push(`paddedProof=${JSON.stringify(paddedProof)}`)
    await shot('04-dark-spanish-padded-detail.png')

    const rich = row('vitest')
    await rich.scrollIntoViewIfNeeded()
    if ((await rich.getAttribute('aria-expanded')) === 'false') await rich.click()
    const richProof = await surface.evaluate(() => {
      const detail = [...document.querySelectorAll('[data-native-chat-window] pre')].map((node) => node.textContent || '').find((text) => text.includes('NativeChatToolLine.test.tsx')) ?? ''
      const row = [...document.querySelectorAll('[data-native-chat-window] button')].find((button) => (button.innerText || '').includes('vitest'))
      return { detail, title: row?.querySelector('[title]')?.getAttribute('title') ?? null }
    })
    if (!richProof.detail.includes('pnpm exec vitest run') || !richProof.title?.includes('NativeChatToolLine.test.tsx')) throw new Error(`rich input missing: ${JSON.stringify(richProof)}`)
    notes.push(`richProof=${JSON.stringify(richProof)}`)
    await shot('05-dark-spanish-rich-command.png')

    const pathProof = await surface.evaluate(() => {
      const button = [...document.querySelectorAll('[data-native-chat-window] button')].find((node) => (node.innerText || '').includes('config.ts'))
      return { text: norm(button?.innerText), title: button?.querySelector('[title]')?.getAttribute('title') ?? null, fullPathInBody: document.body.innerText.includes('C:\\project\\src\\config.ts') }
    })
    if (pathProof.title !== 'C:\\project\\src\\config.ts' || !pathProof.fullPathInBody) throw new Error(`Windows path proof failed: ${JSON.stringify(pathProof)}`)
    notes.push(`pathProof=${JSON.stringify(pathProof)}`)
    await surface.evaluate(async () => {
      const settings = await window.api.settings.set({ theme: 'light', uiLanguage: 'es' })
      window.__store.setState({ settings })
    })
    await surface.waitForFunction(() => document.documentElement.classList.contains('light'), null, { timeout: 10000 })
    await shot('06-light-spanish-overview.png')
    buttons = await surface.evaluate(() => [...document.querySelectorAll('[data-native-chat-window] button')].map((button) => ({ text: (button.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 240), title: button.querySelector('[title]')?.getAttribute('title') ?? button.getAttribute('title'), expanded: button.getAttribute('aria-expanded') })))
    buttonsOpen = buttons
    return { ok: true, notes, buttons, buttonsOpen }
  } catch (error) {
    const message = error instanceof Error ? error.stack || error.message : String(error)
    notes.push(message.split('\n')[0])
    await shot('error.png').catch(() => {})
    return { ok: false, error: message.slice(0, 8000), notes, buttons, buttonsOpen }
  }
}
