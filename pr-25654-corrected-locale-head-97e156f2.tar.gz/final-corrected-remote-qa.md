# PR #25654 corrected final M4Air QA

## Pin, isolation, and result

The owned child remained clean at `97e156f20546a83112bef59d0f867c203458129d`. The one authorized corrected M4Air run used an `env -i` launcher with isolated HOME, `ORCA_DEV_USER_DATA_PATH`, CODEX_HOME, ORCA_CODEX_HOME, CLAUDE_CONFIG_DIR, Grok/XDG paths, mock keychain flags, `ORCA_BACKGROUND_LAUNCH=1`, and hidden CDP automation.

The app's own startup log reports `userData="/Users/m4air/orca-qa/pr-25654/corrected-locale-head/user-data"`, inside the isolated rig. Hooks was unchanged before/after at `78922a784ee78e9e50587e93628cd3b9d4dfbe49087adc4514e6781cea38cbb9`; config was unchanged for this run at `375d81e0cf0617ba4f5e2602fb5e6de646c84b8626d4e95e325f27181d01a2b8` and remains an observation only. The owned launch cleaned up its recorded processes and the worktree stayed clean.

The corrected F5 locale proof passed. The broader acceptance remains incomplete because the required exact padded command detail is truncated at the shared 4,000-character detail cap; no retry or production edit was made.

## Corrected English-to-Spanish same-node proof

The harness seeded experimental native chat, a completed local provider session, the active pane owner, persisted `chatLeafId`, and unified chat view mode. It opened the settled run, collapsed tall command details, stabilized the viewport, and then captured only current individual semantic nodes—not the old invalid array of all window buttons—before changing the language.

The saved English proof confirms connected nodes for the run header, failed Read row, failed Edit row, Subagent row, successful Edit diff-card header, Copy diff button, and the failure-count child span. After one `window.api.settings.set({ theme: 'dark', uiLanguage: 'es' })` plus the normal store propagation, the same retained DOM nodes were connected and selected again, with no disclosure, scroll, theme, or transcript action between snapshot and assertion.

`notes.json` records `same: true` for all seven nodes and these exact Spanish values:

- run: `Se ejecutaron 4 comandos, se leyeron 2 archivos, se editaron 2 archivos, se buscó 2 veces y se ejecutó 1 agente · 4 fallidas`
- failed Read: `Intentó leer config.ts`
- failed Edit: `Intentó editar main.ts`
- Subagent: `Subagente`
- successful edit: `Editó main.ts`
- Copy diff: `Copiar diff`
- child failure count aria label: `Llamadas a herramientas fallidas: 4`

The surrounding app chrome also visibly changed to Spanish. Raw seeded model output remains English by design and was not used as a localization assertion.

## Visible evidence

The uncropped hidden-CDP screenshots are `01-dark-english-collapsed.png`, `02-dark-english-stable-nodes.png`, `03-dark-spanish-same-nodes.png`, and `error.png`. They show real app context, command/failure/read/edit/search/subagent activity, diff rows and counts, full path behavior, and the English-to-Spanish visible update.

The fixture has a `run_in_background` command input but no actual parsed `backgroundTasks` status supplied to the structured session. A native background-task label is therefore untested rather than failed.

## Valid remaining blocker

After the F5 proof, the test opened the padded command detail. The displayed detail was a JSON input representation of length 4,001 (4,000 characters plus an ellipsis), not the full 4,992-character original padded command. `src/shared/native-chat-tool-summary.ts` defines `MAX_TOOL_DETAIL_LENGTH = 4000` and `truncateToolDetail()` adds the ellipsis; the same cap exists in `origin/main` `08a970a3f1176e2de1450acedb706200ef5191fb`.

This is a real failure of the exact-long-detail acceptance requirement, but the offline source comparison shows the truncation mechanism is inherited rather than introduced by PR #25654. No same-machine main launch was performed because the single authorized corrected run was exhausted; no product-cause or severity attribution is made here.

## Coverage limits

The current corrected run did not reach its later rich-command, Windows-path, or light-theme checks after the padded-detail failure. Earlier `second-head` screenshots cover related visible states but its former all-button locale assertion is not used as F5 proof. Windows, Linux, SSH, and mobile runtime remain unverified.
